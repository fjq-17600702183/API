package SelfTest;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import com.alibaba.fastjson.JSONObject;

import sun.misc.BASE64Encoder;

public class Test {
	
//2020/5/22 星期五
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String utf = "utf-8";
		String url = "http://apt.zhixin.net:8711/wndc_newapi";
		String account = "";
		String password = "";
		String encrypt = "5";
		String actionName = "qsfz";
		String api = "s";
		
		String params = "";
		
		com.alibaba.fastjson.JSONObject queryInfo  = new JSONObject();
		queryInfo.put("name", "***");
		queryInfo.put("idCard", "000000000000000000");
//		queryInfo.put("imgB64A", ImageEncoder.imageImageFileToBase64StrLiving("C:\\Users\\Administrator\\Desktop\\test\\接口测试结果\\测试照片\\992.jpg"));

		
		com.alibaba.fastjson.JSONObject baseInfo = new JSONObject();
		baseInfo.put("account", account);
		baseInfo.put("order", qryBatchNo(account));
		baseInfo.put("sign", MD5encrypt16(account + password + queryInfo + baseInfo.getString("order")));
		
		com.alibaba.fastjson.JSONObject jObject = new JSONObject();
		jObject.put("baseInfo", baseInfo);
		jObject.put("queryInfo", queryInfo);
		
		System.out.println("加密串：------------" + jObject.toJSONString());
		
		 //通过文件开始加解密
		ObjectInputStream pupros = new ObjectInputStream(new FileInputStream("pubkey"));
		RSAPublicKey pubkey = (RSAPublicKey) pupros.readObject();
		pupros.close();
		
		System.out.println("加密后的串：" + new BASE64Encoder().encode(RSAUtil.encrypt(pubkey, jObject.toString().getBytes(utf))));
		params = "actionName=" + actionName + "&encrypt=" + encrypt + "&api=" + api + "&params="
				+ new BASE64Encoder().encode(RSAUtil.encrypt(pubkey, jObject.toString().getBytes(utf)));

		
//		System.out.println(url + params);
		byte[] resContent = post(url, params.getBytes(Charset.forName("UTF-8")));
		String resStr = new String(resContent, "UTF-8");
		System.out.println(Thread.currentThread() + " result---> " + resStr.replaceAll("\n", ""));
		
	}
	
	
	
	private static String qryBatchNo(String account)
	{
		String qryBatchNo = account.toUpperCase();
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss"); // 14位
		String temp = sf.format(new Date());
		int random = (int) (Math.random() * 10000);
		qryBatchNo += temp + random;
		return qryBatchNo;
	}
	
	
	private static String imageImageFileToBase64StrLiving(String pathString) {
		String imgBase64 = "";
		try {
			InputStream in = new FileInputStream(pathString);
			BufferedImage bufferedImage = ImageIO.read(in);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			ImageIO.write(bufferedImage, "jpeg", outputStream);

			BASE64Encoder encoder = new BASE64Encoder();
			imgBase64 = encoder.encode(outputStream.toByteArray());

		} catch (IOException e) {
			e.printStackTrace();
		}

		return imgBase64.replaceAll("\\s", "");

	}
	
	
	
	/**
	 * post请求
	 * 
	 * @param url
	 * @return
	 */
	public static byte[] post(String url, byte[] postContent)
	{
		String result = "";
		InputStream in = null;
		HttpURLConnection connection = null;
		OutputStream out = null;
		try
		{
			URL paostUrl = new URL(url);
			// 参数配置
			connection = (HttpURLConnection) paostUrl.openConnection();
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
			connection.setRequestMethod("POST");
			connection.setDoOutput(true); // http正文内，因此需要设为true, 默认情况下是false
			connection.setDoInput(true); // 设置是否从httpUrlConnection读入，默认情况下是true
			connection.setUseCaches(false); // Post 请求不能使用缓存
			connection.setInstanceFollowRedirects(true); // URLConnection.setInstanceFollowRedirects是成员函数，仅作用于当前函数
			connection.setConnectTimeout(30000); // 设置连接主机超时时间
			// connection.setReadTimeout(45000); //设置从主机读取数据超时
			connection.setReadTimeout(120000); // 设置从主机读取数据超时

			// 打开连接
			out = connection.getOutputStream();
			out.write(postContent);
			in = connection.getInputStream();
			return inputStreamToByte(in);
		}
		catch (Exception e)
		{
			throw new RuntimeException("post请求发生异常" + ",url=" + url, e);
		}
		finally
		{
			try
			{
				if (out != null)
				{
					out.close();
				}
				if (in != null)
				{
					in.close();
				}
				if (connection != null)
				{
					connection.disconnect();
				}
			}
			catch (IOException e)
			{
			}
		}
	}
	
	
	
	public static byte[] inputStreamToByte(InputStream in)
	{
		ByteArrayOutputStream out = null;
		try
		{
			int BUFFER_SIZE = 4096;
			out = new ByteArrayOutputStream();
			byte[] data = new byte[BUFFER_SIZE];
			int count = -1;
			while ((count = in.read(data, 0, BUFFER_SIZE)) != -1)
			{
				out.write(data, 0, count);
			}

			return out.toByteArray();
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			try
			{
				in.close();
				out.close();
			}
			catch (IOException e)
			{
			}
		}
	}
	
	/**
	 * @Description:加密-16位大写
	 */
	public static String MD5encrypt16(String encryptStr) {
		return encrypt32(encryptStr).substring(8, 24).toUpperCase();
	}
	
	
	/**
	 * @Description:加密-32位小写
	 */
	public static String encrypt32(String encryptStr) {
		MessageDigest md5;
		try {
			md5 = MessageDigest.getInstance("MD5");
			byte[] md5Bytes = md5.digest(encryptStr.getBytes("UTF-8"));
			StringBuffer hexValue = new StringBuffer();
			for (int i = 0; i < md5Bytes.length; i++) {
				int val = ((int) md5Bytes[i]) & 0xff;
				if (val < 16)
					hexValue.append("0");
				hexValue.append(Integer.toHexString(val));
			}
			encryptStr = hexValue.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return encryptStr;
	}

}
